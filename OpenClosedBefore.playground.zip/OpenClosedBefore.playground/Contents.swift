import Foundation

fileprivate class PaymentManager {
    func makeCashPayment(amount: Double) {
        //perform
    }
    
    func makeVisaPayment(amount: Double) {
        //perform
    }
    
    func makeMasterCardPayment(amount: Double) {
        //perform
    }
}
