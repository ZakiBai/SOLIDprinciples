import Foundation

fileprivate protocol Worker {
    func eat()
    func work()
}

fileprivate class Human: Worker {
    func eat() {
        print("eating")
    }
    
    func work() {
        print("worlking")
    }
}

fileprivate class Robot: Worker {
    func eat() {
        fatalError("Robots does not eat!")
    }
    
    func work() {
        print("working")
    }
}
