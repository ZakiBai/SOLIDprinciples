//Clients should not be forced to depend upon interfaces they do not use.
//When designing a protocol you’ll use in different places in your code, it’s best to break that protocol into multiple smaller pieces where each piece has a specific role. That way, clients depend only on the part of the protocol they need.


import Foundation

fileprivate protocol Feedable {
    func eat()
}

fileprivate protocol Workable {
    func work()
}

fileprivate class Human: Feedable, Workable {
    func eat() {
        print("eating")
    }
    
    func work() {
        print("working")
    }
}


fileprivate class Robot: Workable {
    func work() {
        print("working")
    }
}
