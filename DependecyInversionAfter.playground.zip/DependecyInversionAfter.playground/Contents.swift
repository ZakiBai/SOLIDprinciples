//Depend upon abstractions, not concretions.
//Different parts of your code should not depend on concrete classes. They don’t need that knowledge. This encourages the use of protocols instead of using concrete classes to connect parts of your app


import Foundation

fileprivate protocol Workable {
    func work()
}

fileprivate struct Employee: Workable {
    func work() {
        print("working")
    }
}

fileprivate struct Employer {
    var workables: [Workable]
    
    func manage() {
        workables.forEach { workable in
            workable.work()
        }
    }
}

fileprivate func example() {
    let employer = Employer(workable: [Employee])
    employer.manage()
}
