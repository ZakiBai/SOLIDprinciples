//Software entities, including classes, modules and functions, should be open for extension but closed for modification.
//This means you should be able to expand the capabilities of your types without having to alter them drastically to add what you need.


import Foundation

fileprivate protocol PaymentProtocol {
    func makePayment(amount: Double)
}

fileprivate class CashPayment: PaymentProtocol {
    func makePayment(amount: Double) {
        // perform
    }
}

fileprivate class VisaPayment: PaymentProtocol {
    func makePayment(amount: Double) {
        //perform
    }
}

fileprivate class MasterCardPayment: PaymentProtocol {
    func makePayment(amount: Double) {
        //perform
    }
}

fileprivate class PaymentManager {
    func makePayment(amount: Double, payment: PaymentProtocol) {
        payment.makePayment(amount: amount)
    }
}
