//Objects in a program should be replaceable with instances of their subtypes without altering the correctness of that program.
//In other words, if you replace one object with another that’s a subclass and this replacement could break the affected part, then you’re not following this principle.


import Foundation

fileprivate protocol Polygon {
    func calculateArea() -> Float
}

fileprivate class Rectangle: Polygon {
    var width: Float = 0
    var height: Float = 0
    
    func set(width: Float) {
        self.width = width
    }
    
    func set(height: Float) {
        self.height = height
    }
    
    func calculateArea() -> Float {
        return width * height
    }
}

fileprivate class Square: Polygon {
    var side: Float = 0
    
    func set(side: Float) {
        self.side = side
    }
    
    func calculateArea() -> Float {
        return pow(side, 2)
    }
}

fileprivate class printArea(polygon: Polygon) {
    print(polygon.calculateArea())
}

fileprivate class example() {
    let rectangle = Rectangle()
    rectangle.set(width: 4)
    rectangle.set(height: 5)
    print(printArea(polygon: rectangle))
    
    let square = Square()
    square.set(side: 4)
    print(polygon: square)
    
}
